﻿namespace Conditional_And_Nested_Conditional_statements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}